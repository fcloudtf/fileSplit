﻿using FileSplitFunc;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileSplit
{

    public class RegistryTool
    {
        private static string StringDatas106 = "fdgpgghehhgbhcgffm$fdgpgghehhgbhcgf$";
        private static string[] StringDatas106A = null;
        
        private static string Decodex104(int index107)
        {
            if (StringDatas106A == null) StringDatas106A = StringDatas106.Split((char)(',' - 8));    // '$'
            string data = StringDatas106A[index107];
            data = Infos.codeAlph(data);
            return data;
        }


        public static bool RegistryCotains(string subkey)
        {
            return (Registry.CurrentUser.OpenSubKey(Decodex104(0) + subkey, true) != null);
        }

        public static bool RegistryCotains(string subkey, string name)
        {
            RegistryKey key = Registry.CurrentUser.OpenSubKey(Decodex104(0) + subkey, true);
            if (key == null)
            {
                return false;
            }
            return key.GetValueNames().Contains<string>(name);
        }

        public static void RegistryRemove(string subkey)
        {
            RegistryKey key = Registry.CurrentUser.OpenSubKey(Decodex104(1), true);
            if (Registry.CurrentUser.OpenSubKey(Decodex104(0) + subkey, true) != null)
            {
                key.DeleteSubKeyTree(subkey);
            }
        }

        public static void RegistryRemove(string subkey, string name)
        {
            RegistryKey key = Registry.CurrentUser.OpenSubKey(Decodex104(0) + subkey, true);
            if (key != null)
            {
                key.DeleteValue(name, false);
            }
        }

        public static void RegistrySave(string subkey, string name, object value)
        {
            RegistryKey key = Registry.CurrentUser.OpenSubKey(Decodex104(1), true);
            RegistryKey key2 = Registry.CurrentUser.OpenSubKey(Decodex104(0) + subkey, true);
            if (key2 == null)
            {
                key2 = key.CreateSubKey(subkey);
            }
            key2.SetValue(name, value);
        }

        public static string RegistryStrValue(string subkey, string name)
        {
            object obj2 = RegistryValue(subkey, name);
            return ((obj2 == null) ? Decodex104(2) : obj2.ToString());
        }

        public static object RegistryValue(string subkey, string name)
        {
            RegistryKey key = Registry.CurrentUser.OpenSubKey(Decodex104(0) + subkey, true);
            return ((key == null) ? null : key.GetValue(name, null));
        }
    }
}

