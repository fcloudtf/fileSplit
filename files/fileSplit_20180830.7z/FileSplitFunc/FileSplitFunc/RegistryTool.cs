﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileSplit
{

    public class RegistryTool
    {
        public static bool RegistryCotains(string subkey)
        {
            return (Registry.CurrentUser.OpenSubKey(@"Software\" + subkey, true) != null);
        }

        public static bool RegistryCotains(string subkey, string name)
        {
            RegistryKey key = Registry.CurrentUser.OpenSubKey(@"Software\" + subkey, true);
            if (key == null)
            {
                return false;
            }
            return key.GetValueNames().Contains<string>(name);
        }

        public static void RegistryRemove(string subkey)
        {
            RegistryKey key = Registry.CurrentUser.OpenSubKey("Software", true);
            if (Registry.CurrentUser.OpenSubKey(@"Software\" + subkey, true) != null)
            {
                key.DeleteSubKeyTree(subkey);
            }
        }

        public static void RegistryRemove(string subkey, string name)
        {
            RegistryKey key = Registry.CurrentUser.OpenSubKey(@"Software\" + subkey, true);
            if (key != null)
            {
                key.DeleteValue(name, false);
            }
        }

        public static void RegistrySave(string subkey, string name, object value)
        {
            RegistryKey key = Registry.CurrentUser.OpenSubKey("Software", true);
            RegistryKey key2 = Registry.CurrentUser.OpenSubKey(@"Software\" + subkey, true);
            if (key2 == null)
            {
                key2 = key.CreateSubKey(subkey);
            }
            key2.SetValue(name, value);
        }

        public static string RegistryStrValue(string subkey, string name)
        {
            object obj2 = RegistryValue(subkey, name);
            return ((obj2 == null) ? "" : obj2.ToString());
        }

        public static object RegistryValue(string subkey, string name)
        {
            RegistryKey key = Registry.CurrentUser.OpenSubKey(@"Software\" + subkey, true);
            return ((key == null) ? null : key.GetValue(name, null));
        }
    }
}
